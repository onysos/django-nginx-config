# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import logging
from django.views.generic.base import TemplateView
logger = logging.getLogger(__name__)


from django.shortcuts import render

# Create your views here.
